REGEX_FILE_PY = r'[a-zA-Z0-9/\\]{,100}(.py)$'
REGEX_FILE = r'([a-zA-Z0-9/\\])+((.[a-zA-Z])+)'