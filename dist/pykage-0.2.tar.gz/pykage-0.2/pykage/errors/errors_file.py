
class UnknowTypeFile(TypeError): pass