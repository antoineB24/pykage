class UrlNotFound(NameError): pass

class SiteError(NameError): pass
