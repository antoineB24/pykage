
def hello_world():
    """ Simmple hello world example
    """
    return "Hello world!"


if __name__=="__main__":
    hello_world()
